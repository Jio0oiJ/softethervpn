#include <stdio.h>

int main()
{
	printf("Hello, VPN Hamster !!\n");
	return 0;
}
