// VpnWebControl.cpp : CVpnWebControl
#include "stdafx.h"
#include "VpnWebControl.h"

